import { NgModule, createComponent } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [

  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
    
  },

  
  
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'produit-create',
    loadChildren: () => import('./produit/produit-create/produit-create.module').then( m => m.ProduitCreatePageModule)
  },
  {
    path: 'produit-detail',
    loadChildren: () => import('./produit/produit-detail/produit-detail.module').then( m => m.ProduitDetailPageModule)
  },
  {
    path: 'produit-update',
    loadChildren: () => import('./produit/produit-update/produit-update.module').then( m => m.ProduitUpdatePageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
