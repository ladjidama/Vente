import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Iproduit } from '../produit/produit.model';
import { Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import { NavigationExtras } from '@angular/router';
import { ProduitServiceService } from '../produit/produit-service.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage{
  data :any;
  query = '';
  produit!: Iproduit;
  produits: Iproduit[] = [];
  filteredProduits: Iproduit[]=[];
  constructor(private http :HttpClient,private navCtrl: NavController,private service:ProduitServiceService) {}


  voirProduit(produit: Iproduit) {
    let navigationExtras: NavigationExtras = {
      state: {
        produit: produit
      }
    };
    this.navCtrl.navigateForward('produit-detail', navigationExtras);
  }

  afficher(){
    const url = 'http://api.bitebitego.com/afficher/produit/19/code/4cfe5ea4-308c-48ea-a5a4-47ccb8587083';
    this.http.get<Iproduit>(url).subscribe( (response) => {
      this.produit = response;
    });
  }

  

 
  

  rechercher(): void {
    if (this.query) {
      this.filteredProduits = this.produits.filter(produit =>
        produit.nom.toLowerCase().includes(this.query.toLowerCase())
      );
    } else {
      this.filteredProduits = this.produits;
    }
  }
  
  ngOnInit(){

  this.service.listeProduit().subscribe( (response)=>{
    this.produits = response;
    this.filteredProduits = this.produits;
  })

  

  };

}
