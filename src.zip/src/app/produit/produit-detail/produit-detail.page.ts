import { Component, OnInit } from '@angular/core';
import { Iproduit } from '../produit.model';
import { AlertController } from '@ionic/angular';
import { NavController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { NavigationExtras } from '@angular/router';
import { ProduitServiceService } from '../produit-service.service';

@Component({
  selector: 'app-produit-detail',
  templateUrl: './produit-detail.page.html',
  styleUrls: ['./produit-detail.page.scss'],
})
export class ProduitDetailPage implements OnInit {
  produit: Iproduit | undefined;

  constructor(private alertController: AlertController,private navCtrl:NavController,private http:HttpClient,private service:ProduitServiceService) { if (history.state) {
    this.produit = history.state.produit;
  } }


  modifierProduit(produit:Iproduit) {
    // Ajoutez ici la logique pour modifier le produit
    let navigationExtras: NavigationExtras = {
      state: {
        produit: produit
      }
    };
    this.navCtrl.navigateForward('produit-update', navigationExtras);
  }

  async supprimerProduit() {
    const alert = await this.alertController.create({
      header: 'Confirmation',
      message: 'Voulez-vous vraiment supprimer ce produit ?',
      buttons: [
        {
          text: 'Non',
          role: 'cancel'
        }, {
          text: 'Oui',
          handler: () => {
            
            // Ajoutez ici la logique pour supprimer le produit
            if(this.produit?.produitId)
            {
              
              // this.http.delete(`http://api.bitebitego.com/supprimer/produit/${this.produit.produitId}/code/4cfe5ea4-308c-48ea-a5a4-47ccb8587083`).subscribe(
              //   response => {
              //     // La requête a réussi, naviguez vers la page d'accueil
              //     this.navCtrl.navigateRoot('/home');  // et naviguer vers la page d'accueil
              //   },

                this.service.supprimerProduit(this.produit.produitId).subscribe(
                response => {
                  // La requête a réussi, naviguez vers la page d'accueil
                  this.navCtrl.navigateRoot('');  // et naviguer vers la page d'accueil
                },



                error => {
                  console.log("Echec");
                  // La requête a échoué, affichez une erreur à l'utilisateur
                }
              );
            }
            
            

           

          }
        }
      ]
    });
  
    await alert.present();
  }

  

  ngOnInit() {
  }

}
