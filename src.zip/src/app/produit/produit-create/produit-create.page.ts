import { Component, OnInit } from '@angular/core';
import { Iproduit, Produit } from '../produit.model';
import { HttpClient } from '@angular/common/http';
import { NavController } from '@ionic/angular';
import { ProduitServiceService } from '../produit-service.service';

@Component({
  selector: 'app-produit-create',
  templateUrl: './produit-create.page.html',
  styleUrls: ['./produit-create.page.scss'],
})
export class ProduitCreatePage implements OnInit {
  produit:Iproduit;

  constructor(private http :HttpClient,private navCtrl:NavController,private service:ProduitServiceService) {
    this.produit = {
      produitId:undefined,
      code: '4cfe5ea4-308c-48ea-a5a4-47ccb8587083',
      nom: '',
      description: '',
      quantite: undefined,
      prix: undefined,
      image: '',
      nomPrenomProprietaire: '',
      contactProprietaire: ''
  };
   }

  ajouterProduit() {

    this.service.ajouterProduit(this.produit).subscribe( (produit) => {
      console.log(produit); 
      this.navCtrl.navigateRoot('');
    },
    error => {
      console.log("Veullez vous connecter ");
    }
    );
  }

  ngOnInit() {
  }

}
