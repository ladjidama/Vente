import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ProduitCreatePage } from './produit-create.page';

const routes: Routes = [
  {
    path: '',
    component: ProduitCreatePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ProduitCreatePageRoutingModule {}
