import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ProduitCreatePage } from './produit-create.page';

describe('ProduitCreatePage', () => {
  let component: ProduitCreatePage;
  let fixture: ComponentFixture<ProduitCreatePage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(ProduitCreatePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
