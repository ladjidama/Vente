import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ProduitCreatePageRoutingModule } from './produit-create-routing.module';

import { ProduitCreatePage } from './produit-create.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ProduitCreatePageRoutingModule
  ],
  declarations: [ProduitCreatePage]
})
export class ProduitCreatePageModule {}
