import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Iproduit } from '../produit/produit.model';
import { Observable } from 'rxjs'

@Injectable({
  providedIn: 'root'
})
export class ProduitServiceService {
  private code = '4cfe5ea4-308c-48ea-a5a4-47ccb8587083';
  

  constructor(private http :HttpClient) { }

  listeProduit():Observable<Iproduit[]>{

    const url = 'http://api.bitebitego.com/afficher/produit/19/code/'

    return this.http.get<Iproduit[]>(`http://api.bitebitego.com/afficher/produits/code/${this.code}`)

  }

  modifierProduit(produit: Iproduit): Observable<any> {
    return this.http.put(`http://api.bitebitego.com/modifier/produit/${produit.produitId}/code/${this.code}`, produit);
  }

  supprimerProduit(id: number): Observable<Iproduit> {
    return this.http.delete<Iproduit>(`http://api.bitebitego.com/supprimer/produit/${id}/code/${this.code}`);
  }

  ajouterProduit(produit: Iproduit): Observable<Iproduit> {
    return this.http.post<Iproduit>('http://api.bitebitego.com/ceerproduit', produit);
  }



}
