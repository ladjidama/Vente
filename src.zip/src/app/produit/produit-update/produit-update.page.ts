import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { Iproduit } from '../produit.model';
import { HttpClient } from '@angular/common/http';
import { ProduitServiceService } from '../produit-service.service';

@Component({
  selector: 'app-produit-update',
  templateUrl: './produit-update.page.html',
  styleUrls: ['./produit-update.page.scss'],
})
export class ProduitUpdatePage implements OnInit {
  produit: Iproduit | undefined;

  constructor(private alertController: AlertController,private navCtrl:NavController,private http:HttpClient,private service:ProduitServiceService) {
    if (history.state) {
      this.produit = history.state.produit;
    }
   }

   modifierProduit() {
    
    // Ajoutez ici la logique pour modifier le produit


    if(this.produit?.produitId)
    {

      this.service.modifierProduit(this.produit)
    .subscribe(
      response => {
        // La requête a réussi, naviguez vers la page d'accueil
        this.navCtrl.navigateRoot('');  // et naviguer vers la page d'accueil
      },
      error => {
        console.log("Echec");
        // La requête a échoué, affichez une erreur à l'utilisateur
      }
    );

    }
    
  }

  ngOnInit() {
  }

}
