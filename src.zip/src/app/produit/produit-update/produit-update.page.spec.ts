import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ProduitUpdatePage } from './produit-update.page';

describe('ProduitUpdatePage', () => {
  let component: ProduitUpdatePage;
  let fixture: ComponentFixture<ProduitUpdatePage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(ProduitUpdatePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
