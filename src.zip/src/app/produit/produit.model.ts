export interface Iproduit {
    produitId: number|undefined
    code: string;
    nom: string;
    description: string;
    quantite: number|undefined;
    prix: number|undefined;
    image: string;
    nomPrenomProprietaire: string;
    contactProprietaire: string;
}

export class Produit implements Iproduit {
    constructor(
        public produitId: number,
        public code: string,
        public nom: string,
        public description: string,
        public quantite: number,
        public prix: number,
        public image: string,
        public nomPrenomProprietaire: string,
        public contactProprietaire: string
    ) {}
}
